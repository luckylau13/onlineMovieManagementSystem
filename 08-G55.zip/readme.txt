Readme

Required Software

Latest Java SDK
Netbeans IDE 8.2
GlassFish Server 4.1.1
Web Browser with cookies and javascript enabled.

How To Deploy and run the software

1. Extract OMS folder to your desired folder.
2. Extract the MovieStore folder inside the database.zip to your desired folder. 
3. Copy the MovieStore database folder into your Netbeans\Derby folder. 
   This folder is most likely in “C:\Users\Username\AppData\Roaming\Netbeans\Derby”.
4. Restart Netbeans
5. In NetBeans Go to File -> Open Project
6. Navigate to the directory you copied the OMS folder and select the OMS folder you extracted.
7. Click on Open Project. The project will now load in NetBeans.
8. When the project has loaded Clean and Build the Project by going to Run -  Clean and Build Project
9. Run the project by going to Run - > Run Project. 
10. Go to http://localhost:8080/ in your local web browser.

